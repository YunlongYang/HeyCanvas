package com.example.myapplication

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.jme3.app.jmeSurfaceView.JmeSurfaceView
import com.jme3.system.AppSettings
import java.util.logging.Level
import java.util.logging.Logger

/**
 * 测试在android的原生ui中添加GLSurfaceView
 * 以方便UI和画布交互
 */
class TestGLSurfaceViewActivity : AppCompatActivity() {
    private var testSkyLoading: TestSkyLoading? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test_g_l_surface_view)
        val jmeSurfaceView = findViewById<JmeSurfaceView>(R.id.JmeSurfaceView)
        jmeSurfaceView.setOnRendererCompleted { application, appSettings ->
            logger.log(
                Level.INFO,
                " onRenderCompletion appSetting: $appSettings"
            )
        }
        jmeSurfaceView.setOnExceptionThrown { e ->
            logger.log(
                Level.INFO,
                " onExceptionThrown Throwable: " + e.message
            )
        }
        testSkyLoading = TestSkyLoading()
        val appSettings = AppSettings(true)
        //        appSettings.setGammaCorrection(true);
        appSettings.depthBits = 32
        //        appSettings.set
        testSkyLoading!!.setSettings(appSettings)
        jmeSurfaceView.legacyApplication = testSkyLoading!!
        jmeSurfaceView.startRenderer(200)

//        jmeSurfaceView.setlis
    }

    override fun onDestroy() {
        super.onDestroy()
        if (testSkyLoading != null) testSkyLoading!!.destroy()
        //        if(jmeSurfaceView!=null)
//            jmeSurfaceView.destroy();
    }

    fun change(view: View?) {

    }


    companion object {
        private val logger = Logger.getLogger("testGl")
    }


}