package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    //test skybox
    public fun click(v: View) {
        val intent = Intent(v.context, TestGLSurfaceViewActivity::class.java)
        val bundle = Bundle()
        bundle.putInt("flag",1)
        intent.putExtra("bundle",bundle)
        startActivity(intent)
    }
}